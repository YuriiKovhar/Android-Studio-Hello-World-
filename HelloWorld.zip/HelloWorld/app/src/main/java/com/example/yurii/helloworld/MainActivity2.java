package com.example.yurii.helloworld;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
TextView text1, text2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        text1 = (TextView)findViewById(R.id.editText);
        text2 = (TextView) findViewById(R.id.editText2);
        Bundle bundle = getIntent().getExtras();
        String data1=bundle.getString("uname");
        String data2= bundle.getString("uno");

        text1.setText(data1);
        text2.setText(data2);
    }
}
