package com.example.yurii.helloworld;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity1 extends AppCompatActivity {
EditText urname, urphone;
    Button clk;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main1);
        urname = (EditText) findViewById(R.id.name);
        urphone = (EditText) findViewById(R.id.phoneno);
        clk = (Button) findViewById(R.id.button);
    }
    public void movepage (View v)

    {
        String stname = urname.getText().toString();
        String stphoneno = urphone.getText().toString();

        if (stname.equals("YURII KOVHAR") && stphoneno.equals("0631430454"))
        {
            Intent in = new Intent(MainActivity1.this, MainActivity2.class);
            Bundle bundle = new Bundle();
            bundle.putString("uname" , stname);
            bundle.putString("uno" , stphoneno);
            in.putExtras(bundle);
            startActivity(in);
        }
        else if (stname.equals("") || stphoneno.equals(""))
        {
            Toast.makeText(getBaseContext(), "Enter both Name and Phone number", Toast.LENGTH_SHORT).show();
        }
      else
        {
            Toast.makeText (getBaseContext(),"Wrong Name and/or Phone number entered", Toast.LENGTH_SHORT).show();
        }
    }
}


